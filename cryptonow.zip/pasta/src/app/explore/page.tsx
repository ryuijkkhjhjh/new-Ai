import { redirect } from "next/navigation";

export default function page() {
  redirect("/explore/1");
}
